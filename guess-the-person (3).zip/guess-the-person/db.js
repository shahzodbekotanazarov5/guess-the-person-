const path = require('path');

/*
 * Production note: some free/shared hosts don't have build tools available
 * for native Node modules (better-sqlite3 needs to compile on install).
 * If that happens here, we fall back to a simple in-memory store so the
 * REST/game features keep working — only the persistent leaderboard is lost
 * until the native module issue is fixed on that host.
 */
let mode = 'sqlite';
let db, insertResult, insertChat, leaderboardStmt;
const memory = { results: [], chats: [] };

try {
  const Database = require('better-sqlite3');
  db = new Database(path.join(__dirname, 'game.db'));
  db.pragma('journal_mode = WAL');

  db.exec(`
  CREATE TABLE IF NOT EXISTS game_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    room_code TEXT NOT NULL,
    player_name TEXT NOT NULL,
    found INTEGER NOT NULL DEFAULT 0,
    questions_left INTEGER NOT NULL DEFAULT 0,
    won INTEGER NOT NULL DEFAULT 0,
    finished_at INTEGER NOT NULL
  )`);

  db.exec(`
  CREATE TABLE IF NOT EXISTS chat_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    room_code TEXT NOT NULL,
    player_name TEXT,
    message TEXT NOT NULL,
    is_system INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
  )`);

  insertResult = db.prepare(
    'INSERT INTO game_results (room_code, player_name, found, questions_left, won, finished_at) VALUES (?,?,?,?,?,?)'
  );
  insertChat = db.prepare(
    'INSERT INTO chat_log (room_code, player_name, message, is_system, created_at) VALUES (?,?,?,?,?)'
  );
  leaderboardStmt = db.prepare(`
    SELECT player_name,
           SUM(found) AS total_found,
           SUM(won) AS wins,
           COUNT(*) AS games_played,
           ROUND(AVG(found), 2) AS avg_found
    FROM game_results
    GROUP BY player_name
    ORDER BY wins DESC, total_found DESC
    LIMIT 20
  `);
  console.log('[db] better-sqlite3 ishga tushdi — natijalar game.db fayliga saqlanadi.');
} catch (e) {
  mode = 'memory';
  console.warn('[db] better-sqlite3 ishlamadi (' + e.message + '). Vaqtinchalik xotira rejimiga o\'tildi — server qayta ishga tushganda reyting tozalanadi.');
}

function saveResult(roomCode, playerName, found, questionsLeft, won) {
  if (mode === 'sqlite') {
    insertResult.run(roomCode, playerName, found, questionsLeft, won ? 1 : 0, Date.now());
  } else {
    memory.results.push({ roomCode, playerName, found, questionsLeft, won: !!won, finishedAt: Date.now() });
    if (memory.results.length > 5000) memory.results = memory.results.slice(-5000);
  }
}

function saveChat(roomCode, playerName, message, isSystem) {
  if (mode === 'sqlite') {
    insertChat.run(roomCode, playerName || null, message, isSystem ? 1 : 0, Date.now());
  } else {
    memory.chats.push({ roomCode, playerName, message, isSystem: !!isSystem, createdAt: Date.now() });
    if (memory.chats.length > 5000) memory.chats = memory.chats.slice(-5000);
  }
}

function getLeaderboard() {
  if (mode === 'sqlite') {
    return leaderboardStmt.all();
  }
  const byName = {};
  memory.results.forEach(r => {
    if (!byName[r.playerName]) byName[r.playerName] = { player_name: r.playerName, total_found: 0, wins: 0, games_played: 0 };
    byName[r.playerName].total_found += r.found;
    byName[r.playerName].wins += r.won ? 1 : 0;
    byName[r.playerName].games_played += 1;
  });
  return Object.values(byName)
    .map(x => ({ ...x, avg_found: x.games_played ? Math.round((x.total_found / x.games_played) * 100) / 100 : 0 }))
    .sort((a, b) => (b.wins - a.wins) || (b.total_found - a.total_found))
    .slice(0, 20);
}

module.exports = { saveResult, saveChat, getLeaderboard };
