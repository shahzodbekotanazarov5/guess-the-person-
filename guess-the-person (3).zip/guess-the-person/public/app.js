const socket = io();

let CHAR_DB = [];
let CHAR_MAP = {};
let CATS = [];
let LABEL_BY_VAL = {};

let ME = { name: "" };
let VIEW = "home";
let ROOM_CODE = null;
let STATE = null;
let uiSel = { opponent:null, category:null, mode:null, combo:null };
let infoModalOpen = false;
let infoModalCharId = null;

function escapeHtml(s){ const d=document.createElement("div"); d.textContent=s; return d.innerHTML; }

const el = document.getElementById("screen");
const connBadge = document.getElementById("connBadge");

function toast(msg, kind){
  const t = document.createElement("div");
  t.className = "toast " + (kind||"");
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(()=>t.remove(), 2400);
}

/* ---------------- CHARACTER INFO / DESCRIPTION ---------------- */
function charImg(id){ return "/images/"+id+".png"; }

function describeChar(c){
  const g = c.gender==="male" ? "erkak" : "ayol";
  const hairLenMap = {short:"qisqa", medium:"o'rtacha uzunlikdagi", long:"uzun"};
  const hairTypeMap = {straight:"to'g'ri", wavy:"to'lqinli", curly:"jingalak", braided:"o'rilgan"};
  const hairColorMap = {black:"qora", brown:"jigarrang", blonde:"sariq"};
  const eyeMap = {brown:"jigarrang", blue:"moviy", black:"qora", green:"yashil"};
  const facialMap = {none:"soqol yoki mo'ylovi yo'q", mustache:"mo'ylovi bor", beard:"soqoli bor", both:"soqol va mo'ylovi bor"};
  const clothTypeMap = {hoodie:"hoodie", shirt:"ko'ylak", jacket:"kurtka", sweater:"sviter"};
  const clothColorMap = {black:"qora", green:"yashil", purple:"binafsha", pink:"pushti", blue:"ko'k", white:"oq"};
  const accMap = {none:"aksessuari yo'q", earring:"sirg'a taqadi", hair_accessory:"sochida bezak bor"};

  let parts = [];
  parts.push(c.name + " — " + g + ".");
  parts.push("Sochi " + hairColorMap[c.hair_color] + ", " + hairLenMap[c.hair_length] + " va " + hairTypeMap[c.hair_type] + ".");
  parts.push("Ko'zlari " + eyeMap[c.eye_color] + ".");
  parts.push("Bosh kiyimi " + (c.headwear ? "bor" : "yo'q") + ".");
  parts.push("Ko'zoynak " + (c.glasses ? "taqadi" : "taqmaydi") + ".");
  parts.push(facialMap[c.facial_hair].charAt(0).toUpperCase()+facialMap[c.facial_hair].slice(1)+".");
  parts.push("Kiyimi " + clothColorMap[c.clothing_color] + " rangli " + clothTypeMap[c.clothing_type] + ".");
  parts.push(accMap[c.accessory].charAt(0).toUpperCase()+accMap[c.accessory].slice(1)+".");
  return parts.join(" ");
}

function openInfoModal(charId){
  infoModalOpen = true;
  infoModalCharId = charId || null;
  renderInfoModal();
}
function closeInfoModal(){
  infoModalOpen = false;
  infoModalCharId = null;
  const m = document.getElementById("infoModalRoot");
  if(m) m.remove();
}
function renderInfoModal(){
  let m = document.getElementById("infoModalRoot");
  if(!m){
    m = document.createElement("div");
    m.id = "infoModalRoot";
    m.className = "modal-overlay";
    document.body.appendChild(m);
  }
  if(!infoModalCharId){
    m.innerHTML = `
      <div class="modal-box">
        <div class="modal-head">
          <h3>Personajlar haqida ma'lumot</h3>
          <button class="ghost close-x" id="closeInfoX">✕</button>
        </div>
        <p class="muted center">Kimning ma'lumotini bilmoqchisiz? Tanlang:</p>
        <div class="char-grid" id="infoGrid"></div>
      </div>`;
    const grid = m.querySelector("#infoGrid");
    CHAR_DB.forEach(c=>{
      const card = document.createElement("div");
      card.className = "char-card";
      card.innerHTML = `<img class="avatar-img" src="${charImg(c.id)}" alt="${escapeHtml(c.name)}"><div class="char-name">${escapeHtml(c.name)}</div>`;
      card.onclick = ()=>{ infoModalCharId = c.id; renderInfoModal(); };
      grid.appendChild(card);
    });
  } else {
    const c = CHAR_MAP[infoModalCharId];
    m.innerHTML = `
      <div class="modal-box">
        <div class="modal-head">
          <h3>${escapeHtml(c.name)}</h3>
          <button class="ghost close-x" id="closeInfoX">✕</button>
        </div>
        <div class="info-detail">
          <img class="avatar-img-big" src="${charImg(c.id)}" alt="${escapeHtml(c.name)}">
          <p>${escapeHtml(describeChar(c))}</p>
        </div>
        <button class="ghost" id="backToGridBtn">← Boshqa personaj</button>
      </div>`;
    m.querySelector("#backToGridBtn").onclick = ()=>{ infoModalCharId = null; renderInfoModal(); };
  }
  m.querySelector("#closeInfoX").onclick = closeInfoModal;
  m.onclick = (e)=>{ if(e.target===m) closeInfoModal(); };
}
function ensureInfoButton(){
  if(document.getElementById("infoFab")) return;
  const btn = document.createElement("button");
  btn.id = "infoFab";
  btn.className = "info-fab";
  btn.textContent = "?";
  btn.title = "Personajlar haqida ma'lumot";
  btn.onclick = ()=>openInfoModal(null);
  document.body.appendChild(btn);
}

/* ---------------- SOCKET EVENTS ---------------- */
socket.on("connect", ()=>{
  connBadge.textContent = "🟢 ulangan";
  connBadge.className = "conn-badge conn-on";
  if(ROOM_CODE && ME.name){
    socket.emit("join_room", { code: ROOM_CODE, name: ME.name }, (res)=>{});
  }
});
socket.on("disconnect", ()=>{
  connBadge.textContent = "🔴 aloqa uzildi, qayta ulanmoqda...";
  connBadge.className = "conn-badge conn-off";
});
socket.on("catalog", (data)=>{
  CHAR_DB = data.characters;
  CHAR_MAP = Object.fromEntries(CHAR_DB.map(c=>[c.id,c]));
  CATS = data.categories;
  LABEL_BY_VAL = {};
  CATS.forEach(c=>c.opts.forEach(([v,l])=>LABEL_BY_VAL[c.key+":"+v]=l));
  render();
  ensureInfoButton();
});
socket.on("toast", ({msg, kind})=> toast(msg, kind));
socket.on("room_state", (state)=>{
  STATE = state;
  ROOM_CODE = state.code;
  if(state.status === "lobby") VIEW = "lobby";
  else if(state.status === "selecting") VIEW = "select";
  else if(state.status === "playing") VIEW = "game";
  else if(state.status === "finished") VIEW = "result";
  render();
  if(infoModalOpen) renderInfoModal();
});

/* ---------------- ACTIONS ---------------- */
function checkName(){
  const input = document.getElementById("nameInput");
  if(input) ME.name = input.value.trim();
  if(!ME.name){ toast("Iltimos ismingizni kiriting","no"); return false; }
  return true;
}
function createRoom(maxPlayers){
  if(!checkName()) return;
  socket.emit("create_room", { name: ME.name, maxPlayers }, (res)=>{
    if(res && res.error) return toast(res.error, "no");
  });
}
function joinRoom(code){
  if(!checkName()) return;
  code = (code||"").trim().toUpperCase();
  if(!code){ toast("Xona kodini kiriting","no"); return; }
  socket.emit("join_room", { code, name: ME.name }, (res)=>{
    if(res && res.error) return toast(res.error, "no");
  });
}
function toggleReady(){ socket.emit("toggle_ready"); }
function startGame(){ socket.emit("start_game"); }
function pickCharacter(charId){ socket.emit("pick_character", { charId }); }
function askQuestion(targetId, catKey, val){
  socket.emit("ask_question", { targetId, catKey, val });
  uiSel = { opponent:null, category:null, mode:null, combo:null };
}
function askCombo(targetId, combo){
  socket.emit("ask_combo", { targetId, combo });
  uiSel = { opponent:null, category:null, mode:null, combo:null };
}
function makeGuess(targetId, charId){
  socket.emit("make_guess", { targetId, charId });
  uiSel = { opponent:null, category:null, mode:null, combo:null };
}
function sendChat(text){
  if(!text.trim()) return;
  socket.emit("send_chat", { text: text.trim() });
}
function backToHome(){
  socket.emit("leave_room");
  ROOM_CODE = null; STATE = null; VIEW = "home"; render();
}

/* ---------------- RENDER ---------------- */
function render(){
  el.innerHTML = "";
  if(VIEW==="home") return renderHome();
  if(VIEW==="lobby") return renderLobby();
  if(VIEW==="select") return renderSelect();
  if(VIEW==="game") return renderGame();
  if(VIEW==="result") return renderResult();
}

function renderHome(){
  const wrap = document.createElement("div");
  wrap.className = "card stack";
  wrap.innerHTML = `
    <h2 class="center">Xush kelibsiz</h2>
    <div class="stack">
      <label class="muted">Ismingiz</label>
      <input type="text" id="nameInput" placeholder="Masalan: Shahzod" value="${escapeHtml(ME.name)}">
    </div>
    <div class="grid-2">
      <div class="card stack">
        <h3>🎮 Yangi o'yin</h3>
        <label class="muted">O'yinchilar soni</label>
        <div class="row">
          <button class="ghost" id="p3">3 o'yinchi</button>
          <button class="ghost" id="p4">4 o'yinchi</button>
        </div>
      </div>
      <div class="card stack">
        <h3>🔑 Xonaga kirish</h3>
        <input type="text" id="codeInput" class="mono" placeholder="ROOM CODE" style="text-transform:uppercase">
        <button id="joinBtn">Kirish</button>
      </div>
    </div>
    <button class="ghost" id="browseBtn">👤 42 ta personajni ko'rish</button>
    <p class="muted center">Do'stlaringiz bilan real vaqtda o'ynash uchun ularga shu sayt manzilini va xona kodini yuboring. Istalgan payt pastdagi "?" tugmasini bosib har qanday personaj haqida ma'lumot olishingiz mumkin.</p>
  `;
  el.appendChild(wrap);
  document.getElementById("nameInput").oninput = e=>{ ME.name = e.target.value; };
  document.getElementById("p3").onclick = ()=>createRoom(3);
  document.getElementById("p4").onclick = ()=>createRoom(4);
  document.getElementById("joinBtn").onclick = ()=>joinRoom(document.getElementById("codeInput").value);
  document.getElementById("browseBtn").onclick = ()=>openInfoModal(null);
}

function renderLobby(){
  const r = STATE;
  const wrap = document.createElement("div");
  wrap.className = "card stack";
  const me = r.players.find(p=>p.name===ME.name) || r.players[0];
  wrap.innerHTML = `
    <div class="code-display mono">${r.code}</div>
    <p class="muted center">Do'stlaringizga shu kodni yuboring (${r.players.length}/${r.maxPlayers})</p>
    <div class="stack" id="plist"></div>
    <div class="row center" style="justify-content:center">
      <button id="readyBtn">${me.ready ? "✅ Tayyor" : "Tayyorman"}</button>
      ${r.hostId===socket.id ? '<button class="ghost" id="startBtn">O\'yinni boshlash</button>' : ''}
    </div>
    <p class="muted center" id="hint"></p>
    <button class="ghost" id="leaveBtn">← Chiqish</button>
  `;
  el.appendChild(wrap);
  const plist = wrap.querySelector("#plist");
  r.players.forEach(p=>{
    const chip = document.createElement("div");
    chip.className = "player-chip";
    chip.innerHTML = `<span><span class="dot ${p.ready?'on':'off'}"></span>${escapeHtml(p.name)}${p.id===r.hostId?' <span class="badge">host</span>':''}${!p.connected?' <span class="badge">uzilgan</span>':''}</span><span class="muted">${p.ready?'tayyor':'kutilmoqda'}</span>`;
    plist.appendChild(chip);
  });
  wrap.querySelector("#readyBtn").onclick = toggleReady;
  const startBtn = wrap.querySelector("#startBtn");
  if(startBtn) startBtn.onclick = startGame;
  wrap.querySelector("#leaveBtn").onclick = backToHome;
  const hint = wrap.querySelector("#hint");
  if(r.players.length<3) hint.textContent = "Boshlash uchun kamida 3 o'yinchi kerak.";
  else if(!r.players.every(p=>p.ready)) hint.textContent = "Hamma o'yinchi tayyor bo'lishi kerak.";
}

function renderSelect(){
  const r = STATE;
  const me = r.players.find(p=>p.id===socket.id);
  const wrap = document.createElement("div");
  wrap.className = "card stack";
  wrap.innerHTML = `
    <h2 class="center">Yashirin personajingizni tanlang</h2>
    <p class="muted center">Boshqalar sizning personajingizni ko'rmaydi. Har bir kartaning ustidagi ⓘ belgisini bosib personaj haqida to'liq ma'lumot olishingiz mumkin.</p>
    <div class="char-grid" id="grid"></div>
    <p class="center muted" id="status"></p>
  `;
  el.appendChild(wrap);
  const grid = wrap.querySelector("#grid");
  CHAR_DB.forEach(c=>{
    const isTaken = r.takenCharIds.includes(c.id) && (!me || me.targetCharId!==c.id);
    const card = document.createElement("div");
    card.className = "char-card" + (me && me.targetCharId===c.id?" selected":"") + (isTaken?" dimmed":"");
    card.innerHTML = `
      <div class="card-inner">
        <img class="avatar-img" src="${charImg(c.id)}" alt="${escapeHtml(c.name)}">
        <button class="info-i" data-id="${c.id}" title="Ma'lumot">ⓘ</button>
      </div>
      <div class="char-name">${escapeHtml(c.name)}</div>`;
    if(!isTaken) card.querySelector(".avatar-img").onclick = ()=>pickCharacter(c.id);
    card.querySelector(".info-i").onclick = (e)=>{ e.stopPropagation(); openInfoModal(c.id); };
    grid.appendChild(card);
  });
  const readyCount = r.players.filter(p=>p.hasPicked).length;
  wrap.querySelector("#status").textContent = (me && me.targetCharId)
    ? `Siz "${CHAR_MAP[me.targetCharId].name}"ni tanladingiz. Boshqalarni kutyapmiz (${readyCount}/${r.players.length})...`
    : "Personajni tanlang (rasm ustiga bosib).";
}

function attrMatches(char, key, val){
  let v = char[key];
  if(typeof v === "boolean") v = String(v);
  return String(v) === String(val);
}
function candidateCountFor(targetId){
  const pairKey = socket.id+"->"+targetId;
  const asked = (STATE.askedQuestions[pairKey]) || [];
  let candidates = CHAR_DB;
  asked.forEach(q=>{
    if(q.combo){
      candidates = candidates.filter(c => q.correct ? q.comboArr.every(x=>attrMatches(c,x.key,x.val)) : !q.comboArr.every(x=>attrMatches(c,x.key,x.val)));
    } else {
      candidates = candidates.filter(c => q.correct ? attrMatches(c,q.catKey,q.val) : !attrMatches(c,q.catKey,q.val));
    }
  });
  return candidates;
}

function renderGame(){
  const r = STATE;
  const me = r.players.find(p=>p.id===socket.id);
  const currentId = r.currentTurnId;
  const current = r.players.find(p=>p.id===currentId);
  const isMyTurn = currentId===socket.id && !me.eliminated;

  const wrap = document.createElement("div");
  wrap.className = "stack";
  wrap.innerHTML = `<div class="card center" style="padding:12px;">
      <span class="badge">Navbat: <b style="color:var(--gold)">${current?escapeHtml(current.name):"—"}</b>${isMyTurn?" (siz)":""}</span>
      &nbsp; <span class="badge">Savol imkoniyati: ${me.questionsLeft}</span>
      &nbsp; <span class="badge">Topilganlar: ${me.found}</span>
      ${me.eliminated ? '&nbsp; <span class="badge" style="color:var(--red);border-color:var(--red)">👁 Siz tomoshabinsiz</span>' : ''}
    </div>`;
  const layout = document.createElement("div");
  layout.className = "layout3";
  wrap.appendChild(layout);
  el.appendChild(wrap);

  const left = document.createElement("div");
  left.className = "card";
  left.innerHTML = `<h3>O'yinchilar</h3>`;
  r.players.filter(p=>p.id!==socket.id).forEach(p=>{
    const div = document.createElement("div");
    div.className = "opp-card" + (uiSel.opponent===p.id?" active-turn":"") + (p.eliminated?" eliminated-card":"");
    if(p.eliminated){
      const rc = CHAR_MAP[p.revealedCharId];
      div.innerHTML = `<b>${escapeHtml(p.name.toUpperCase())}</b> <span class="badge" style="color:var(--red);border-color:var(--red)">chiqdi</span>
        <div class="cnt">Personaji edi: ${rc?escapeHtml(rc.name):"?"}</div>`;
    } else {
      const cands = candidateCountFor(p.id);
      div.innerHTML = `<b>${escapeHtml(p.name.toUpperCase())}</b>${!p.connected?' <span class="badge">uzilgan</span>':''}<div class="cnt">${cands.length} kandidat</div>`;
      if(isMyTurn) div.onclick = ()=>{ uiSel.opponent = p.id; uiSel.category=null; uiSel.mode=null; render(); };
    }
    left.appendChild(div);
  });
  layout.appendChild(left);

  const center = document.createElement("div");
  center.className = "card";
  layout.appendChild(center);
  renderCenter(center, r, me, isMyTurn);

  const right = document.createElement("div");
  right.className = "card stack";
  right.innerHTML = `<h3>💬 Chat</h3><div class="chat-box" id="chatBox"></div>
    <div class="row"><input type="text" id="chatInput" placeholder="Xabar..."><button id="sendChat">➤</button></div>`;
  layout.appendChild(right);
  const chatBox = right.querySelector("#chatBox");
  (r.chat||[]).forEach(m=>{
    const d = document.createElement("div");
    d.className = "chat-msg";
    d.innerHTML = m.sys ? `<i style="color:var(--text-dim)">${escapeHtml(m.text)}</i>` : `<b>${escapeHtml(m.name)}:</b> ${escapeHtml(m.text)}`;
    chatBox.appendChild(d);
  });
  chatBox.scrollTop = chatBox.scrollHeight;
  right.querySelector("#sendChat").onclick = ()=>{
    const inp = right.querySelector("#chatInput");
    sendChat(inp.value); inp.value="";
  };
  right.querySelector("#chatInput").onkeydown = (e)=>{
    if(e.key==="Enter"){ sendChat(e.target.value); e.target.value=""; }
  };
}

function renderCenter(center, r, me, isMyTurn){
  if(me.eliminated){
    center.innerHTML = `<h3 class="center">👁 Tomoshabin rejimi</h3><p class="muted center">Sizning yashirin personajingiz topildi. Endi o'yinni kuzatib, chatda yozishingiz mumkin.</p>`;
    return;
  }
  if(!isMyTurn){
    const cur = r.players.find(p=>p.id===r.currentTurnId);
    center.innerHTML = `<h3 class="center">Kuting...</h3><p class="muted center">Hozir ${cur?escapeHtml(cur.name):""}ning navbati.</p>`;
    return;
  }
  if(!uiSel.opponent){
    center.innerHTML = `<h3 class="center">Kimdan so'raysiz?</h3><p class="muted center">Chapdan (o'yindan chiqmagan) raqibni tanlang.</p>`;
    return;
  }
  const opp = r.players.find(p=>p.id===uiSel.opponent);
  if(!opp || opp.eliminated){ uiSel.opponent=null; center.innerHTML=""; return; }
  if(!uiSel.mode){
    center.innerHTML = `<h3 class="center">${escapeHtml(opp.name)}</h3>`;
    const row = document.createElement("div");
    row.className = "row"; row.style.justifyContent="center";
    const qBtn = document.createElement("button"); qBtn.textContent="❓ Savol berish";
    qBtn.onclick = ()=>{ uiSel.mode="question"; render(); };
    const gBtn = document.createElement("button"); gBtn.className="ghost"; gBtn.textContent="🎯 Taxmin qilish";
    gBtn.onclick = ()=>{ uiSel.mode="guess"; render(); };
    row.appendChild(qBtn); row.appendChild(gBtn);
    center.appendChild(row);

    const hist = document.createElement("div");
    hist.className = "qhistory";
    const pairKey = socket.id+"->"+opp.id;
    const asked = (r.askedQuestions[pairKey]||[]).slice().reverse();
    asked.forEach(q=>{
      const label = q.combo ? q.comboArr.map(c=>LABEL_BY_VAL[c.key+":"+c.val]||c.val).join(" + ") : (CATS.find(c=>c.key===q.catKey).label+": "+(LABEL_BY_VAL[q.catKey+":"+q.val]||q.val));
      const line = document.createElement("div");
      line.textContent = label + " → " + (q.correct?"TO'G'RI":"NOTO'G'RI");
      hist.appendChild(line);
    });
    center.appendChild(hist);
    return;
  }
  if(uiSel.mode==="question"){
    if(!uiSel.category){
      center.innerHTML = `<h3 class="center">Kategoriya tanlang</h3>`;
      const grid = document.createElement("div");
      grid.className = "stack";
      CATS.forEach(cat=>{
        const b = document.createElement("button");
        b.className = "cat-btn"; b.textContent = cat.label;
        b.onclick = ()=>{ uiSel.category = cat.key; render(); };
        grid.appendChild(b);
      });
      const comboB = document.createElement("button");
      comboB.className = "cat-btn"; comboB.textContent = "🔥 Maxsus (kombinatsiya) savol";
      comboB.onclick = ()=>{ uiSel.category = "__combo__"; render(); };
      grid.appendChild(comboB);
      const back = document.createElement("button");
      back.className = "ghost"; back.textContent = "← Orqaga"; back.style.marginTop="8px";
      back.onclick = ()=>{ uiSel.mode=null; render(); };
      grid.appendChild(back);
      center.appendChild(grid);
      return;
    }
    if(uiSel.category==="__combo__"){
      if(!uiSel.combo){
        let tries=0, combo=null;
        while(tries<30 && !combo){
          tries++;
          const c1 = CATS[Math.floor(Math.random()*CATS.length)];
          const o1 = c1.opts[Math.floor(Math.random()*c1.opts.length)];
          const c2 = CATS[Math.floor(Math.random()*CATS.length)];
          const o2 = c2.opts[Math.floor(Math.random()*c2.opts.length)];
          if(c1.key===c2.key) continue;
          const arr = [{key:c1.key,val:o1[0]},{key:c2.key,val:o2[0]}];
          const cnt = CHAR_DB.filter(c=>arr.every(x=>attrMatches(c,x.key,x.val))).length;
          if(cnt>=2 && cnt<=40) combo = arr;
        }
        uiSel.combo = combo;
      }
      if(!uiSel.combo){
        center.innerHTML = `<p class="center muted">Kombinatsiya topilmadi, qayta urinib ko'ring.</p>`;
        const back = document.createElement("button"); back.className="ghost"; back.textContent="← Orqaga";
        back.onclick = ()=>{ uiSel.category=null; uiSel.combo=null; render(); };
        center.appendChild(back);
        return;
      }
      const labelStr = uiSel.combo.map(c=>LABEL_BY_VAL[c.key+":"+c.val]||c.val).join(" + ");
      center.innerHTML = `<h3 class="center">Maxsus savol</h3><p class="center" style="font-size:1.1em">${labelStr}?</p>`;
      const row = document.createElement("div"); row.className="row"; row.style.justifyContent="center";
      const ask = document.createElement("button"); ask.textContent="Shu savolni berish";
      ask.onclick = ()=>askCombo(opp.id, uiSel.combo);
      const skip = document.createElement("button"); skip.className="ghost"; skip.textContent="Boshqa kombinatsiya";
      skip.onclick = ()=>{ uiSel.combo=null; render(); };
      const back = document.createElement("button"); back.className="ghost"; back.textContent="← Orqaga";
      back.onclick = ()=>{ uiSel.category=null; uiSel.combo=null; render(); };
      row.appendChild(ask); row.appendChild(skip); row.appendChild(back);
      center.appendChild(row);
      return;
    }
    const cat = CATS.find(c=>c.key===uiSel.category);
    const pairKey = socket.id+"->"+opp.id;
    const asked = (r.askedQuestions[pairKey]||[]).map(q=>q.qid);
    center.innerHTML = `<h3 class="center">${cat.label}</h3>`;
    const grid = document.createElement("div");
    grid.className = "stack";
    cat.opts.forEach(([val,label])=>{
      const qid = cat.key+":"+val;
      const b = document.createElement("button");
      b.className = "opt-btn"; b.textContent = label+"?";
      if(asked.includes(qid)) b.disabled = true;
      else b.onclick = ()=>askQuestion(opp.id, cat.key, val);
      grid.appendChild(b);
    });
    const back = document.createElement("button");
    back.className = "ghost"; back.textContent = "← Orqaga"; back.style.marginTop="8px";
    back.onclick = ()=>{ uiSel.category=null; render(); };
    grid.appendChild(back);
    center.appendChild(grid);
    return;
  }
  if(uiSel.mode==="guess"){
    center.innerHTML = `<h3 class="center">${escapeHtml(opp.name)}ning personaji qaysi?</h3><p class="muted center">Noto'g'ri bo'lsa −2 savol imkoniyati. To'g'ri bo'lsa, ${escapeHtml(opp.name)} o'yindan chiqadi!</p>`;
    const grid = document.createElement("div");
    grid.className = "char-grid";
    CHAR_DB.forEach(c=>{
      const card = document.createElement("div");
      card.className = "char-card";
      card.innerHTML = `
        <div class="card-inner">
          <img class="avatar-img" src="${charImg(c.id)}" alt="${escapeHtml(c.name)}">
          <button class="info-i" data-id="${c.id}" title="Ma'lumot">ⓘ</button>
        </div>
        <div class="char-name">${escapeHtml(c.name)}</div>`;
      card.querySelector(".avatar-img").onclick = ()=>{ if(confirm(c.name+" deb taxmin qilasizmi?")) makeGuess(opp.id, c.id); };
      card.querySelector(".info-i").onclick = (e)=>{ e.stopPropagation(); openInfoModal(c.id); };
      grid.appendChild(card);
    });
    center.appendChild(grid);
    const back = document.createElement("button");
    back.className = "ghost"; back.textContent = "← Orqaga"; back.style.marginTop="10px";
    back.onclick = ()=>{ uiSel.mode=null; render(); };
    center.appendChild(back);
  }
}

function renderResult(){
  const r = STATE;
  const sorted = r.players.slice().sort((a,b)=>{
    const aScore = a.id===r.winnerId ? 9999 : (a.eliminatedOrder||0);
    const bScore = b.id===r.winnerId ? 9999 : (b.eliminatedOrder||0);
    if(aScore!==bScore) return bScore-aScore;
    return b.found - a.found;
  });
  const wrap = document.createElement("div");
  wrap.className = "card stack";
  const medals = ["🥇","🥈","🥉","4️⃣"];
  wrap.innerHTML = `<h2 class="center">🏆 NATIJALAR</h2>`;
  sorted.forEach((p,i)=>{
    const row = document.createElement("div");
    row.className = "result-row";
    const winTag = p.id===r.winnerId ? " (G'OLIB)" : "";
    row.innerHTML = `<span>${medals[i]||("#"+(i+1))} ${escapeHtml(p.name)}${winTag}</span><span>${p.found} ta topdi</span>`;
    wrap.appendChild(row);
  });
  const home = document.createElement("button");
  home.textContent = "Bosh sahifaga qaytish"; home.style.marginTop="16px";
  home.onclick = backToHome;
  wrap.appendChild(home);
  el.appendChild(wrap);
}

render();
ensureInfoButton();
