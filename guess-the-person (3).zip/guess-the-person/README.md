# Guess the Person — real-time multiplayer (production-ready)

Node.js + Express + Socket.IO backend, SQLite (yoki avtomatik xotira zaxirasi) database, va vanilla HTML/JS frontend — barchasi bitta serverda birga xizmat qiladi (frontend uchun alohida hosting shart emas).

## 1. Kompyuteringizda tekshirib ko'rish (ixtiyoriy, hosting'dan oldin)

```bash
npm install
npm start
```

`http://localhost:3000` — bu faqat SIZNING kompyuteringizda ishlaydi, boshqalar kira olmaydi. Do'stlaringiz bilan haqiqatan o'ynash uchun pastdagi hosting bosqichlaridan birini bajaring.

## 2. Online hosting qilish

Bu loyiha **doimiy ishlab turadigan Node.js serverini** talab qiladi (Socket.IO WebSocket ulanishi uchun). Statik hosting (InfinityFree, GitHub Pages, oddiy shared PHP hosting) ISHLAMAYDI.

### Variant A — Render.com (tavsiya etiladi, bepul)

1. Loyihani GitHub'ga yuklang (`git init`, `git add .`, `git commit`, GitHub'da repo yaratib push qiling — `.gitignore` allaqachon `node_modules` va `game.db`ni chiqarib tashlaydi).
2. [render.com](https://render.com) → GitHub bilan kiring → **New +** → **Web Service** → repongizni tanlang.
3. Sozlamalar:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Instance Type:** Free
4. **Create Web Service** — bir necha daqiqada `https://xxxxx.onrender.com` manzili tayyor bo'ladi.

Eslatma: bepul reja 15 daqiqa harakatsizlikdan keyin "uxlab qoladi", birinchi kirishda 30-60 soniya kutish kerak bo'lishi mumkin.

### Variant B — Railway.app

GitHub repo'ni ulaysiz, Railway avtomatik `package.json`ni aniqlab `npm install && npm start`ni bajaradi. Sozlamalarga tegish shart emas.

### Variant C — o'zingizning VPS'ingiz

```bash
# serverda (Ubuntu misolida):
sudo apt update && sudo apt install -y nodejs npm build-essential
git clone <sizning-repo> && cd guess-the-person
npm install
npm install -g pm2
pm2 start server.js --name guess-the-person
pm2 save
```
Keyin Nginx orqali 80/443 portidan `localhost:3000`ga reverse proxy sozlang (HTTPS uchun Certbot tavsiya etiladi).

## 3. Production uchun qilingan tayyorgarliklar (kod ichida)

- Server porti `process.env.PORT`dan olinadi — barcha hosting platformalar buni o'zi beradi, qo'lda sozlash shart emas.
- `server.listen(PORT, '0.0.0.0', ...)` — server tashqi tarmoq interfeyslaridan kirishga ochiq.
- `app.set('trust proxy', 1)` — hostlar odatda reverse proxy orqasida ishlaydi, bu sozlama to'g'ri ishlashi uchun kerak.
- CORS manzili ixtiyoriy `CLIENT_ORIGIN` environment o'zgaruvchisi orqali cheklab qo'yish mumkin (`.env.example`ga qarang) — sozlanmasa hammaga ochiq (`*`) bo'lib qoladi, bu loyihaning o'zida (frontend+backend bir joyda) muammo emas.
- **Database xavfsizligi:** agar hostingda `better-sqlite3` moduli kompilyatsiya bo'lmasa (ba'zi bepul hostlarda build vositalari yo'q bo'lishi mumkin), server buzilib qolmaydi — avtomatik vaqtinchalik xotira rejimiga o'tadi (faqat serverni qayta ishga tushirsangiz reyting tozalanadi, o'yinning o'zi to'liq ishlayveradi).

## 4. MUHIM: SQLite fayli hosting'da doimiy emas

Render/Railway kabi platformalarning **bepul rejasida fayl tizimi vaqtinchalik** — har safar serverni qayta deploy qilganingizda yoki u qayta ishga tushganda `game.db` fayli **o'chib ketadi**, ya'ni umumiy reyting (`/api/leaderboard`) nolga tushadi. Faol o'yin xonalari ham xotirada saqlangani uchun restart paytida yo'qoladi.

Agar reyting/tarixni doimiy saqlashni xohlasangiz:
- Render'da **Persistent Disk** qo'shish (pullik reja), yoki
- Tashqi bulutli database (masalan Supabase, PlanetScale, Neon Postgres) ulash — bu keyingi bosqich, xohlasangiz shu bo'yicha ham kod yozib beraman.

Hozircha: **bitta o'yin sessiyasi davomida** hamma narsa (xona, chat, natijalar) mukammal ishlaydi — faqat server qayta ishga tushganda tarix yo'qolishini bilib qo'ying.

## 5. Fayllar tuzilishi

```
guess-the-person/
├── package.json
├── server.js       ← barcha o'yin mantig'i (server-authoritative)
├── db.js           ← SQLite (yoki xotira zaxirasi)
├── Procfile        ← ba'zi hostlar uchun (Heroku-uslub)
├── .gitignore
├── .env.example
├── game.db          (avtomatik yaratiladi, git'ga tushmaydi)
└── public/
    ├── index.html
    ├── app.js       ← client interfeysi
    └── images/       (42 ta personaj surati)
```

## 6. Xususiyatlar (qisqacha)

- Ism bilan kirish (akkaunt/parol yo'q), 3 yoki 4 kishilik xona, kod orqali qo'shilish.
- 42 personaj — haqiqiy rasmlar bilan, "?" tugmasi orqali istalgan personaj haqida to'liq ma'lumot.
- Savol-javob, maxsus kombinatsiya savollar, chat — barchasi real vaqtda (Socket.IO).
- UNO uslubidagi davomiylik: kimning personaji topilsa, o'sha o'yindan chiqib tomoshabin bo'ladi; oxirida bitta g'olib qoladi.
- Tugagan o'yinlar natijasi saqlanadi (`/api/leaderboard`).
