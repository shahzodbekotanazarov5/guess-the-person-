const express = require('express');
const http = require('http');
const path = require('path');
const { Server } = require('socket.io');
const db = require('./db');

const app = express();
app.set('trust proxy', 1); // most hosts (Render/Railway/etc.) sit behind a reverse proxy

const server = http.createServer(app);

// In production you can restrict this to your real domain via an env var,
// e.g. CLIENT_ORIGIN=https://your-app.onrender.com
// Left as "*" by default so it works out of the box on any host/port.
const ALLOWED_ORIGIN = process.env.CLIENT_ORIGIN || '*';
const io = new Server(server, { cors: { origin: ALLOWED_ORIGIN } });

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

app.get('/api/leaderboard', (req, res) => {
  res.json(db.getLeaderboard());
});

app.get('/health', (req, res) => res.json({ ok: true, rooms: Object.keys(rooms).length }));

/* ============================================================
   CHARACTER DATABASE (public knowledge - like a real board game,
   every player can see all characters' traits and photos; only
   the player -> character ASSIGNMENT is secret, kept server-side)
   ============================================================ */
const CHAR_DB = [
{id:1,name:"Shahzod",gender:"male",hair_length:"short",hair_color:"black",hair_type:"straight",headwear:true,glasses:false,eye_color:"brown",facial_hair:"none",clothing_type:"hoodie",clothing_color:"black",accessory:"none"},
{id:2,name:"Javohir",gender:"male",hair_length:"medium",hair_color:"black",hair_type:"wavy",headwear:false,glasses:true,eye_color:"black",facial_hair:"none",clothing_type:"jacket",clothing_color:"black",accessory:"none"},
{id:3,name:"Munisa",gender:"female",hair_length:"long",hair_color:"black",hair_type:"straight",headwear:true,glasses:false,eye_color:"green",facial_hair:"none",clothing_type:"hoodie",clothing_color:"black",accessory:"earring"},
{id:4,name:"E’zoza",gender:"female",hair_length:"long",hair_color:"brown",hair_type:"wavy",headwear:true,glasses:false,eye_color:"green",facial_hair:"none",clothing_type:"shirt",clothing_color:"pink",accessory:"hair_accessory"},
{id:5,name:"Dilnoza",gender:"female",hair_length:"medium",hair_color:"black",hair_type:"wavy",headwear:false,glasses:true,eye_color:"brown",facial_hair:"none",clothing_type:"shirt",clothing_color:"purple",accessory:"earring"},
{id:6,name:"Malak",gender:"female",hair_length:"long",hair_color:"blonde",hair_type:"wavy",headwear:true,glasses:false,eye_color:"blue",facial_hair:"none",clothing_type:"shirt",clothing_color:"blue",accessory:"hair_accessory"},
{id:7,name:"Umid",gender:"male",hair_length:"short",hair_color:"black",hair_type:"wavy",headwear:false,glasses:false,eye_color:"brown",facial_hair:"none",clothing_type:"jacket",clothing_color:"green",accessory:"none"},
{id:8,name:"Madina",gender:"female",hair_length:"long",hair_color:"blonde",hair_type:"wavy",headwear:false,glasses:true,eye_color:"green",facial_hair:"none",clothing_type:"shirt",clothing_color:"black",accessory:"earring"},
{id:9,name:"Dilorabo",gender:"female",hair_length:"long",hair_color:"brown",hair_type:"curly",headwear:true,glasses:false,eye_color:"brown",facial_hair:"none",clothing_type:"shirt",clothing_color:"pink",accessory:"hair_accessory"},
{id:10,name:"Dilso‘z",gender:"female",hair_length:"long",hair_color:"brown",hair_type:"wavy",headwear:false,glasses:false,eye_color:"blue",facial_hair:"none",clothing_type:"shirt",clothing_color:"purple",accessory:"hair_accessory"},
{id:11,name:"Aziz",gender:"male",hair_length:"short",hair_color:"black",hair_type:"curly",headwear:false,glasses:false,eye_color:"black",facial_hair:"none",clothing_type:"hoodie",clothing_color:"green",accessory:"none"},
{id:12,name:"Bekzod",gender:"male",hair_length:"short",hair_color:"brown",hair_type:"wavy",headwear:false,glasses:true,eye_color:"brown",facial_hair:"none",clothing_type:"hoodie",clothing_color:"black",accessory:"none"},
{id:13,name:"Sardor",gender:"male",hair_length:"short",hair_color:"blonde",hair_type:"wavy",headwear:false,glasses:false,eye_color:"blue",facial_hair:"none",clothing_type:"sweater",clothing_color:"green",accessory:"none"},
{id:14,name:"Anvar",gender:"male",hair_length:"short",hair_color:"black",hair_type:"straight",headwear:true,glasses:false,eye_color:"black",facial_hair:"mustache",clothing_type:"hoodie",clothing_color:"black",accessory:"none"},
{id:15,name:"Rustam",gender:"male",hair_length:"short",hair_color:"brown",hair_type:"wavy",headwear:false,glasses:false,eye_color:"brown",facial_hair:"mustache",clothing_type:"shirt",clothing_color:"white",accessory:"none"},
{id:16,name:"Farrux",gender:"male",hair_length:"medium",hair_color:"black",hair_type:"curly",headwear:false,glasses:false,eye_color:"black",facial_hair:"beard",clothing_type:"hoodie",clothing_color:"white",accessory:"none"},
{id:17,name:"Sanjar",gender:"male",hair_length:"short",hair_color:"black",hair_type:"wavy",headwear:false,glasses:false,eye_color:"brown",facial_hair:"none",clothing_type:"hoodie",clothing_color:"purple",accessory:"none"},
{id:18,name:"Humoyun",gender:"male",hair_length:"short",hair_color:"blonde",hair_type:"wavy",headwear:false,glasses:true,eye_color:"blue",facial_hair:"none",clothing_type:"hoodie",clothing_color:"white",accessory:"none"},
{id:19,name:"Jasur",gender:"male",hair_length:"short",hair_color:"black",hair_type:"straight",headwear:true,glasses:false,eye_color:"brown",facial_hair:"none",clothing_type:"hoodie",clothing_color:"blue",accessory:"none"},
{id:20,name:"Ulug‘bek",gender:"male",hair_length:"medium",hair_color:"brown",hair_type:"wavy",headwear:false,glasses:true,eye_color:"green",facial_hair:"beard",clothing_type:"jacket",clothing_color:"green",accessory:"none"},
{id:21,name:"Ravshan",gender:"male",hair_length:"short",hair_color:"brown",hair_type:"wavy",headwear:true,glasses:false,eye_color:"brown",facial_hair:"none",clothing_type:"hoodie",clothing_color:"green",accessory:"none"},
{id:22,name:"Sulton",gender:"male",hair_length:"short",hair_color:"black",hair_type:"straight",headwear:false,glasses:false,eye_color:"black",facial_hair:"none",clothing_type:"jacket",clothing_color:"pink",accessory:"none"},
{id:23,name:"Akmal",gender:"male",hair_length:"short",hair_color:"black",hair_type:"straight",headwear:true,glasses:false,eye_color:"brown",facial_hair:"mustache",clothing_type:"hoodie",clothing_color:"purple",accessory:"none"},
{id:24,name:"Doston",gender:"male",hair_length:"short",hair_color:"brown",hair_type:"curly",headwear:true,glasses:true,eye_color:"green",facial_hair:"none",clothing_type:"hoodie",clothing_color:"purple",accessory:"none"},
{id:25,name:"Kamron",gender:"male",hair_length:"short",hair_color:"black",hair_type:"straight",headwear:true,glasses:false,eye_color:"blue",facial_hair:"none",clothing_type:"hoodie",clothing_color:"green",accessory:"none"},
{id:26,name:"Bobur",gender:"male",hair_length:"medium",hair_color:"black",hair_type:"curly",headwear:false,glasses:false,eye_color:"black",facial_hair:"beard",clothing_type:"hoodie",clothing_color:"white",accessory:"none"},
{id:27,name:"Gulnoza",gender:"female",hair_length:"long",hair_color:"black",hair_type:"curly",headwear:false,glasses:true,eye_color:"green",facial_hair:"none",clothing_type:"shirt",clothing_color:"green",accessory:"earring"},
{id:28,name:"Mohira",gender:"female",hair_length:"long",hair_color:"blonde",hair_type:"wavy",headwear:true,glasses:false,eye_color:"blue",facial_hair:"none",clothing_type:"jacket",clothing_color:"blue",accessory:"none"},
{id:29,name:"Rayhona",gender:"female",hair_length:"long",hair_color:"black",hair_type:"wavy",headwear:false,glasses:true,eye_color:"brown",facial_hair:"none",clothing_type:"shirt",clothing_color:"purple",accessory:"earring"},
{id:30,name:"Zebo",gender:"female",hair_length:"long",hair_color:"brown",hair_type:"curly",headwear:false,glasses:false,eye_color:"black",facial_hair:"none",clothing_type:"shirt",clothing_color:"white",accessory:"none"},
{id:31,name:"Shahnoza",gender:"female",hair_length:"long",hair_color:"black",hair_type:"braided",headwear:true,glasses:false,eye_color:"brown",facial_hair:"none",clothing_type:"shirt",clothing_color:"green",accessory:"earring"},
{id:32,name:"Feruza",gender:"female",hair_length:"long",hair_color:"brown",hair_type:"curly",headwear:false,glasses:true,eye_color:"blue",facial_hair:"none",clothing_type:"hoodie",clothing_color:"blue",accessory:"none"},
{id:33,name:"Nargiza",gender:"female",hair_length:"long",hair_color:"brown",hair_type:"wavy",headwear:true,glasses:false,eye_color:"green",facial_hair:"none",clothing_type:"hoodie",clothing_color:"pink",accessory:"earring"},
{id:34,name:"Zarina",gender:"female",hair_length:"long",hair_color:"brown",hair_type:"straight",headwear:false,glasses:false,eye_color:"brown",facial_hair:"none",clothing_type:"sweater",clothing_color:"green",accessory:"earring"},
{id:35,name:"Sevinch",gender:"female",hair_length:"long",hair_color:"black",hair_type:"straight",headwear:true,glasses:true,eye_color:"black",facial_hair:"none",clothing_type:"shirt",clothing_color:"black",accessory:"earring"},
{id:36,name:"Shaxlo",gender:"female",hair_length:"long",hair_color:"black",hair_type:"straight",headwear:true,glasses:true,eye_color:"brown",facial_hair:"none",clothing_type:"shirt",clothing_color:"white",accessory:"none"},
{id:37,name:"Charos",gender:"female",hair_length:"long",hair_color:"black",hair_type:"braided",headwear:false,glasses:false,eye_color:"green",facial_hair:"none",clothing_type:"shirt",clothing_color:"white",accessory:"none"},
{id:38,name:"Malika",gender:"female",hair_length:"long",hair_color:"black",hair_type:"wavy",headwear:false,glasses:false,eye_color:"green",facial_hair:"none",clothing_type:"shirt",clothing_color:"purple",accessory:"hair_accessory"},
{id:39,name:"Nigora",gender:"female",hair_length:"long",hair_color:"blonde",hair_type:"curly",headwear:false,glasses:false,eye_color:"blue",facial_hair:"none",clothing_type:"shirt",clothing_color:"pink",accessory:"none"},
{id:40,name:"Lola",gender:"female",hair_length:"medium",hair_color:"black",hair_type:"wavy",headwear:false,glasses:true,eye_color:"black",facial_hair:"none",clothing_type:"shirt",clothing_color:"blue",accessory:"earring"},
{id:41,name:"Shahzoda",gender:"female",hair_length:"long",hair_color:"brown",hair_type:"wavy",headwear:true,glasses:false,eye_color:"green",facial_hair:"none",clothing_type:"shirt",clothing_color:"white",accessory:"hair_accessory"},
{id:42,name:"Gulbahor",gender:"female",hair_length:"long",hair_color:"black",hair_type:"straight",headwear:true,glasses:false,eye_color:"brown",facial_hair:"none",clothing_type:"shirt",clothing_color:"green",accessory:"earring"}
];
const CHAR_MAP = Object.fromEntries(CHAR_DB.map(c => [c.id, c]));

const CATS = [
  { key: 'gender', label: "Jinsi", opts: [['male', 'Erkakmi?'], ['female', 'Ayolmi?']] },
  { key: 'hair_length', label: "Soch uzunligi", opts: [['short', 'Qisqami?'], ['medium', "O'rtachami?"], ['long', 'Uzunmi?']] },
  { key: 'hair_type', label: "Soch turi", opts: [['straight', "To'g'rimi?"], ['wavy', "To'lqinlimi?"], ['curly', 'Jingalakmi?'], ['braided', "O'rilganmi?"]] },
  { key: 'hair_color', label: "Soch rangi", opts: [['black', 'Qorami?'], ['brown', 'Jigarrangmi?'], ['blonde', 'Sariqmi?']] },
  { key: 'eye_color', label: "Ko'z rangi", opts: [['blue', 'Moviymi?'], ['green', 'Yashilmi?'], ['brown', 'Jigarrangmi?'], ['black', 'Qorami?']] },
  { key: 'headwear', label: 'Bosh kiyimi', opts: [['true', 'Bor'], ['false', "Yo'q"]] },
  { key: 'glasses', label: "Ko'zoynak", opts: [['true', 'Bor'], ['false', "Yo'q"]] },
  { key: 'facial_hair', label: "Soqol/mo'ylov", opts: [['none', "Yo'q"], ['mustache', "Mo'ylov"], ['beard', 'Soqol'], ['both', "Soqol va mo'ylov"]] },
  { key: 'clothing_type', label: 'Kiyim turi', opts: [['hoodie', 'Hoodie'], ['shirt', "Ko'ylak"], ['jacket', 'Kurtka'], ['sweater', 'Sviter']] },
  { key: 'clothing_color', label: 'Kiyim rangi', opts: [['black', 'Qora'], ['green', 'Yashil'], ['purple', 'Binafsha'], ['pink', 'Pushti'], ['blue', "Ko'k"], ['white', 'Oq']] },
  { key: 'accessory', label: 'Aksessuar', opts: [['none', "Yo'q"], ['earring', "Sirg'a"], ['hair_accessory', 'Soch bezagi']] }
];
const LABEL_BY_VAL = {};
CATS.forEach(c => c.opts.forEach(([v, l]) => LABEL_BY_VAL[c.key + ':' + v] = l));

function attrMatches(char, key, val) {
  let v = char[key];
  if (typeof v === 'boolean') v = String(v);
  return String(v) === String(val);
}

function genCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let s = '';
  for (let i = 0; i < 5; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

/* ============================================================
   IN-MEMORY ROOM STATE (server is authoritative)
   Game flow: UNO-style continuous turns. When a player's secret
   character is correctly guessed by anyone, that player is
   ELIMINATED (their secret is revealed) and becomes a spectator.
   The game continues among remaining active players until only
   one remains — that player wins.
   ============================================================ */
const rooms = {};

function buildStateFor(room, viewerId) {
  return {
    code: room.code,
    hostId: room.hostId,
    maxPlayers: room.maxPlayers,
    status: room.status,
    turnOrder: room.turnOrder,
    turnPos: room.turnPos,
    currentTurnId: room.status === 'playing' ? room.turnOrder[room.turnPos] : null,
    askedQuestions: room.askedQuestions,
    chat: room.chat.slice(-80),
    guesses: room.guesses,
    takenCharIds: room.players.filter(p => p.id !== viewerId && p.targetCharId).map(p => p.targetCharId),
    winnerId: room.winnerId || null,
    players: room.players.map(p => ({
      id: p.id,
      name: p.name,
      ready: p.ready,
      found: p.found,
      questionsLeft: p.questionsLeft,
      connected: p.connected,
      hasPicked: !!p.targetCharId,
      eliminated: !!p.eliminated,
      eliminatedOrder: p.eliminatedOrder || null,
      revealedCharId: p.eliminated ? p.targetCharId : null,
      targetCharId: p.id === viewerId ? p.targetCharId : null
    }))
  };
}

function broadcastRoom(code) {
  const room = rooms[code];
  if (!room) return;
  room.players.forEach(p => {
    if (p.connected) io.to(p.id).emit('room_state', buildStateFor(room, p.id));
  });
}

function pushChat(room, entry) {
  room.chat.push(entry);
  if (room.chat.length > 300) room.chat = room.chat.slice(-300);
  try { db.saveChat(room.code, entry.name || null, entry.text, !!entry.sys); } catch (e) { /* non-fatal */ }
}

function activePlayers(room) {
  return room.players.filter(p => !p.eliminated);
}

function advanceTurn(room) {
  if (!room.turnOrder || !room.turnOrder.length) return;
  const n = room.turnOrder.length;
  for (let i = 1; i <= n; i++) {
    const idx = (room.turnPos + i) % n;
    const pid = room.turnOrder[idx];
    const player = room.players.find(p => p.id === pid);
    if (player && !player.eliminated) { room.turnPos = idx; return; }
  }
}

function eliminatePlayer(room, player) {
  player.eliminated = true;
  room.eliminationCounter = (room.eliminationCounter || 0) + 1;
  player.eliminatedOrder = room.eliminationCounter;
}

function finishGameIfDone(room) {
  const active = activePlayers(room);
  if (active.length <= 1) {
    room.status = 'finished';
    room.winnerId = active.length === 1 ? active[0].id : null;
    room.players.forEach(p => {
      try { db.saveResult(room.code, p.name, p.found, p.questionsLeft, p.id === room.winnerId); } catch (e) { /* non-fatal */ }
    });
    return true;
  }
  return false;
}

function migratePlayerId(room, oldId, newId) {
  if (room.hostId === oldId) room.hostId = newId;
  if (room.winnerId === oldId) room.winnerId = newId;
  if (room.turnOrder) room.turnOrder = room.turnOrder.map(id => id === oldId ? newId : id);
  const newAsked = {};
  Object.keys(room.askedQuestions).forEach(k => {
    const idx = k.indexOf('->');
    const a = k.slice(0, idx), b = k.slice(idx + 2);
    const na = a === oldId ? newId : a;
    const nb = b === oldId ? newId : b;
    newAsked[na + '->' + nb] = room.askedQuestions[k];
  });
  room.askedQuestions = newAsked;
  room.guesses.forEach(g => {
    if (g.by === oldId) g.by = newId;
    if (g.target === oldId) g.target = newId;
  });
}

io.on('connection', (socket) => {
  socket.emit('catalog', { characters: CHAR_DB, categories: CATS });

  socket.on('create_room', ({ name, maxPlayers }, ack) => {
    name = (name || '').trim().slice(0, 24);
    if (!name) return ack && ack({ error: 'Ism kerak' });
    const code = genCode();
    const room = {
      code,
      hostId: socket.id,
      maxPlayers: maxPlayers === 4 ? 4 : 3,
      status: 'lobby',
      players: [{ id: socket.id, name, ready: false, targetCharId: null, found: 0, questionsLeft: 20, connected: true, eliminated: false, eliminatedOrder: null }],
      turnOrder: [],
      turnPos: 0,
      askedQuestions: {},
      chat: [],
      guesses: [],
      eliminationCounter: 0,
      winnerId: null,
      createdAt: Date.now()
    };
    rooms[code] = room;
    socket.join(code);
    socket.data.room = code;
    ack && ack({ ok: true, code });
    broadcastRoom(code);
  });

  socket.on('join_room', ({ code, name }, ack) => {
    code = (code || '').trim().toUpperCase();
    name = (name || '').trim().slice(0, 24);
    const room = rooms[code];
    if (!room) return ack && ack({ error: 'Xona topilmadi' });
    if (!name) return ack && ack({ error: 'Ism kerak' });

    const existingSameName = room.players.find(p => p.name === name);
    if (existingSameName && !existingSameName.connected) {
      const oldId = existingSameName.id;
      migratePlayerId(room, oldId, socket.id);
      existingSameName.id = socket.id;
      existingSameName.connected = true;
      socket.join(code);
      socket.data.room = code;
      ack && ack({ ok: true, code, reconnected: true });
      pushChat(room, { sys: true, text: name + ' qayta ulandi', ts: Date.now() });
      broadcastRoom(code);
      return;
    }

    if (room.status !== 'lobby') return ack && ack({ error: "O'yin allaqachon boshlangan" });
    if (room.players.length >= room.maxPlayers) return ack && ack({ error: "Xona to'lgan" });
    if (room.players.some(p => p.name === name)) return ack && ack({ error: 'Bu ism band, boshqa ism tanlang' });

    room.players.push({ id: socket.id, name, ready: false, targetCharId: null, found: 0, questionsLeft: 20, connected: true, eliminated: false, eliminatedOrder: null });
    socket.join(code);
    socket.data.room = code;
    ack && ack({ ok: true, code });
    pushChat(room, { sys: true, text: name + " xonaga qo'shildi", ts: Date.now() });
    broadcastRoom(code);
  });

  socket.on('toggle_ready', () => {
    const room = rooms[socket.data.room]; if (!room) return;
    const me = room.players.find(p => p.id === socket.id); if (!me) return;
    me.ready = !me.ready;
    broadcastRoom(room.code);
  });

  socket.on('start_game', () => {
    const room = rooms[socket.data.room]; if (!room) return;
    if (room.hostId !== socket.id) return;
    if (room.players.length < 3) return socket.emit('toast', { msg: "Kamida 3 o'yinchi kerak", kind: 'no' });
    if (!room.players.every(p => p.ready)) return socket.emit('toast', { msg: "Hamma tayyor bo'lishi kerak", kind: 'no' });
    room.status = 'selecting';
    broadcastRoom(room.code);
  });

  socket.on('pick_character', ({ charId }) => {
    const room = rooms[socket.data.room]; if (!room) return;
    if (room.status !== 'selecting') return;
    if (!CHAR_MAP[charId]) return;
    const taken = room.players.some(p => p.targetCharId === charId && p.id !== socket.id);
    if (taken) return socket.emit('toast', { msg: "Bu personajni boshqa o'yinchi tanlagan", kind: 'no' });
    const me = room.players.find(p => p.id === socket.id); if (!me) return;
    me.targetCharId = charId;
    if (room.players.every(p => p.targetCharId)) {
      room.status = 'playing';
      room.turnOrder = room.players.map(p => p.id);
      room.turnPos = 0;
      pushChat(room, { sys: true, text: "O'yin boshlandi! Navbat: " + room.players[0].name, ts: Date.now() });
    }
    broadcastRoom(room.code);
  });

  socket.on('ask_question', ({ targetId, catKey, val }) => {
    const room = rooms[socket.data.room]; if (!room || room.status !== 'playing') return;
    if (room.turnOrder[room.turnPos] !== socket.id) return socket.emit('toast', { msg: 'Sizning navbatingiz emas', kind: 'no' });
    if (targetId === socket.id) return;
    const cat = CATS.find(c => c.key === catKey); if (!cat) return;
    if (!cat.opts.some(o => o[0] === String(val))) return;
    const targetPlayer = room.players.find(p => p.id === targetId); if (!targetPlayer || targetPlayer.eliminated) return;
    const pairKey = socket.id + '->' + targetId;
    if (!room.askedQuestions[pairKey]) room.askedQuestions[pairKey] = [];
    const qid = catKey + ':' + val;
    if (room.askedQuestions[pairKey].some(q => q.qid === qid)) return socket.emit('toast', { msg: 'Bu savol allaqachon berilgan', kind: 'no' });
    const targetChar = CHAR_MAP[targetPlayer.targetCharId];
    const correct = attrMatches(targetChar, catKey, val);
    room.askedQuestions[pairKey].push({ qid, catKey, val, correct, ts: Date.now() });
    const asker = room.players.find(p => p.id === socket.id);
    const label = LABEL_BY_VAL[qid] || val;
    pushChat(room, { sys: true, text: asker.name + ' -> ' + targetPlayer.name + ': ' + cat.label + ' — ' + label + ' => ' + (correct ? "TO'G'RI ✅" : "NOTO'G'RI ❌"), ts: Date.now() });
    advanceTurn(room);
    broadcastRoom(room.code);
  });

  socket.on('ask_combo', ({ targetId, combo }) => {
    const room = rooms[socket.data.room]; if (!room || room.status !== 'playing') return;
    if (room.turnOrder[room.turnPos] !== socket.id) return;
    if (targetId === socket.id) return;
    if (!Array.isArray(combo) || combo.length < 2) return;
    for (const c of combo) {
      const cat = CATS.find(x => x.key === c.key);
      if (!cat || !cat.opts.some(o => o[0] === String(c.val))) return;
    }
    const targetPlayer = room.players.find(p => p.id === targetId); if (!targetPlayer || targetPlayer.eliminated) return;
    const pairKey = socket.id + '->' + targetId;
    if (!room.askedQuestions[pairKey]) room.askedQuestions[pairKey] = [];
    const qid = 'combo:' + combo.map(c => c.key + '=' + c.val).join(',');
    if (room.askedQuestions[pairKey].some(q => q.qid === qid)) return;
    const targetChar = CHAR_MAP[targetPlayer.targetCharId];
    const correct = combo.every(c => attrMatches(targetChar, c.key, c.val));
    room.askedQuestions[pairKey].push({ qid, combo: true, comboArr: combo, correct, ts: Date.now() });
    const asker = room.players.find(p => p.id === socket.id);
    const labelStr = combo.map(c => LABEL_BY_VAL[c.key + ':' + c.val] || c.val).join(' + ');
    pushChat(room, { sys: true, text: asker.name + ' -> ' + targetPlayer.name + ': [' + labelStr + '] => ' + (correct ? "TO'G'RI ✅" : "NOTO'G'RI ❌"), ts: Date.now() });
    advanceTurn(room);
    broadcastRoom(room.code);
  });

  socket.on('make_guess', ({ targetId, charId }) => {
    const room = rooms[socket.data.room]; if (!room || room.status !== 'playing') return;
    if (room.turnOrder[room.turnPos] !== socket.id) return;
    if (targetId === socket.id) return;
    if (!CHAR_MAP[charId]) return;
    const me = room.players.find(p => p.id === socket.id);
    const targetPlayer = room.players.find(p => p.id === targetId); if (!targetPlayer || targetPlayer.eliminated) return;
    const correct = targetPlayer.targetCharId === charId;
    room.guesses.push({ by: socket.id, target: targetId, charId, correct, ts: Date.now() });
    const charName = CHAR_MAP[charId].name;
    if (correct) {
      me.found += 1;
      eliminatePlayer(room, targetPlayer);
      pushChat(room, { sys: true, text: '🎉 ' + me.name + ' ' + targetPlayer.name + "ning yashirin personajini topdi: " + charName + "! " + targetPlayer.name + " o'yindan chiqdi va tomoshabin bo'ldi.", ts: Date.now() });
    } else {
      me.questionsLeft = Math.max(0, me.questionsLeft - 2);
      pushChat(room, { sys: true, text: '❌ ' + me.name + " noto'g'ri taxmin qildi (" + targetPlayer.name + ' -> ' + charName + '). -2 savol.', ts: Date.now() });
    }
    const done = finishGameIfDone(room);
    if (!done) advanceTurn(room);
    else pushChat(room, { sys: true, text: room.winnerId ? ("🏆 O'yin tugadi! G'olib: " + room.players.find(p=>p.id===room.winnerId).name) : "O'yin tugadi!", ts: Date.now() });
    broadcastRoom(room.code);
  });

  socket.on('send_chat', ({ text }) => {
    const room = rooms[socket.data.room]; if (!room) return;
    text = (text || '').trim().slice(0, 300); if (!text) return;
    const me = room.players.find(p => p.id === socket.id); if (!me) return;
    pushChat(room, { name: me.name, text, ts: Date.now() });
    broadcastRoom(room.code);
  });

  socket.on('leave_room', () => {
    const code = socket.data.room; const room = rooms[code]; if (!room) return;
    const me = room.players.find(p => p.id === socket.id);
    if (me) {
      me.connected = false;
      pushChat(room, { sys: true, text: me.name + " o'yinni tark etdi", ts: Date.now() });
      broadcastRoom(code);
    }
    socket.leave(code);
    socket.data.room = null;
  });

  socket.on('disconnect', () => {
    const code = socket.data.room; const room = rooms[code]; if (!room) return;
    const me = room.players.find(p => p.id === socket.id);
    if (me) {
      me.connected = false;
      pushChat(room, { sys: true, text: me.name + ' aloqadan uzildi', ts: Date.now() });
      broadcastRoom(code);
    }
  });
});

const PORT = process.env.PORT || 3000;
// bind to 0.0.0.0 explicitly so it's reachable on any hosting platform's network interface
server.listen(PORT, '0.0.0.0', () => console.log('Guess the Person server running on port ' + PORT));
